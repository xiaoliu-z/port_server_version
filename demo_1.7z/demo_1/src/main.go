package main

import (
	"fmt"
	"fuzz_port/cmd"
	"fuzz_port/my_var"
)

func init() {
	cmd.INIT()
	fmt.Printf("%s\n", my_var.Banner)
	fmt.Printf(my_var.ServiceName + " v" + my_var.Version + "\n\n")
	fmt.Printf("Api:http://0.0.0.0:61360\n\n")
}

func main() {
	cmd.Run()
}
