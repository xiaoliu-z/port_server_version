package probe_scan

import (
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"fuzz_port/my_var"
	"net"
	"strconv"
	"strings"
	"time"
)

// ProbeScan 构造函数
func newProbe(protocol string, ip string, port int64) *my_var.ProbeScan {
	var tmpProbes []my_var.Probe
	alternateDNS := []string{"localhost"}
	crt, key := my_var.GenerateSelfSignedCertKey(2048, "127.0.0.1", []net.IP{net.ParseIP(ip)}, alternateDNS)
	cert, err := tls.X509KeyPair(crt, key)
	if err != nil {
		fmt.Println("failed to X509KeyPair")
	}

	clientCertPool := x509.NewCertPool()
	ok := clientCertPool.AppendCertsFromPEM(crt)
	if !ok {
		fmt.Println("failed to parse root certificate")
	}
	conf := &tls.Config{
		RootCAs:            clientCertPool,
		Certificates:       []tls.Certificate{cert},
		InsecureSkipVerify: true,
	}
	if protocol == "tcp" {
		tmpProbes = my_var.TcpProbe
	} else {
		tmpProbes = my_var.UDPProbe
	}

	return &my_var.ProbeScan{
		Protocol: protocol,
		Ip:       ip,
		Port:     port,
		Result:   my_var.ProbeResult{},
		TlsConf:  conf,
		Probes:   tmpProbes,
	}
}

func Scan(protocol string, ip string, port int64) (int64, []byte) {

	_, err := net.DialTimeout(protocol, ip+":"+strconv.FormatInt(port, 10), 5*time.Second)
	if err != nil {
		return 0, []byte("can't get banner")
	}
	// 创建对象
	myScan := newProbe(protocol, ip, port)
	// 获取符合条件的探针然后顺序执行
	myScan.UseProbe()
	// 如果未获取端口响应将剩余的探针也进行执行
	if string(myScan.Result.Banner) == "empty response" || len(myScan.Result.Banner) == 0 {
		myScan.AllProbe()
	}
	sslFlag := strings.Trim(strconv.QuoteToASCII(string(myScan.Result.Banner)), "\"")
	if strings.HasPrefix(sslFlag, `\x15`) || strings.HasPrefix(sslFlag, `\x16`) || strings.HasPrefix(sslFlag, `\x17`) {
		fmt.Println("sslscan")
		myScan.SslScan()
	}

	// 扫描过程中发现端口响应为空--->
	if len(myScan.Result.Banner) == 0 {
		return 0, []byte("can't get banner")
	} else if string(myScan.Result.Banner) == "empty response" {
		return 0, []byte("empty response")
	} else {
		return myScan.Result.ProbeId, myScan.Result.Banner
	}
}
