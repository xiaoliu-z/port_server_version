package core

import (
	"fmt"
	"fuzz_port/my_var"
	"net"
	"strconv"
	"strings"
)

func ParseIP(s string) net.IP {
	ip := net.ParseIP(s)
	if ip == nil {
		return nil
	}
	for i := 0; i < len(s); i++ {
		switch s[i] {
		case '.':
			return ip
		case ':':
			return ip
		}
	}
	return nil
}

func CheckPort(port int64) bool {
	if port > 1 && port <= 65535 {
		return true
	} else {
		return false
	}
}

func Verified(parameter *my_var.Parameter) (*[]my_var.Target, bool) {
	var results []my_var.Target
	if strings.ToLower(parameter.Protocol) != "tcp" && strings.ToLower(parameter.Protocol) != "udp" {
		fmt.Println("protocol错误目前只支持tcp和udp")
		return nil, false
	}
	ip := ParseIP(parameter.Ip)
	if ip == nil {
		fmt.Println("ip格式错误请输入正确的ipv4或ipv6地址")
		return nil, false
	}
	ok := CheckPort(parameter.Port)
	if !ok {
		fmt.Println("端口范围应该在1-65535之内")
		return nil, false
	}
	results = append(results, my_var.Target{
		Port:     parameter.Port,
		Protocol: parameter.Protocol,
		Ip:       parameter.Ip,
	})
	if len(parameter.Targets) != 0 {
		targets := strings.Split(parameter.Targets, ",")
		for _, target := range targets {
			tmp := strings.Split(target, ":")
			if len(tmp) == 3 {
				if strings.ToLower(tmp[0]) != "tcp" && strings.ToLower(tmp[0]) != "udp" {
					fmt.Println("protocol错误目前只支持tcp和udp")
					return nil, false
				}
				err := ParseIP(tmp[1])
				tmpInt, err1 := strconv.Atoi(tmp[2])
				ok := CheckPort(int64(tmpInt))
				if err == nil || err1 != nil || ok == false {
					fmt.Println("请标准输入protocol:ip:port,protocol:ip:port")
					return nil, false
				}
				results = append(results, my_var.Target{
					Port:     int64(tmpInt),
					Protocol: tmp[0],
					Ip:       tmp[1],
				})
			} else {
				fmt.Println("请标准输入ip:port,ip:port")
				return nil, false
			}
		}
	}

	return &results, true
}
