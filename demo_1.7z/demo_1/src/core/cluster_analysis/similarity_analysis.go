package cluster_analysis

import (
	"fmt"
	"github.com/hyperjumptech/beda"
	"math"
)

const LengthDifference = 0.35
const ChangeDistance = 0.45
const JDiffDegree = 0.6
const TDiffDegree = 0.6

func SimilarityAnalysis(sample, sample2 string, fineness int32) bool {
	var quota int32
	if len(sample) == 0 || len(sample2) == 0 {
		fmt.Println("[***][!]String length cannot be 0")
		return false
	}
	if len(sample) > 512 && len(sample2) > 512 {
		sample = sample[:512]
		sample2 = sample2[:512]
	}
	// 判断两个字符串的长度差异，长度差异过大，判定为不相似
	Lengthdiff := math.Abs(float64(len(sample) - len(sample2)))
	if (Lengthdiff / float64(len(sample))) > LengthDifference {
		return false
	}
	sd := beda.NewStringDiff(sample, sample2)
	//Levenshtein Distance将一个单词更改为另一个单词所需的最小单字符编辑次数，因此结果是一个正整数。该算法对字符串长度敏感。
	lDist := sd.LevenshteinDistance()
	// 如果两个字符串完全相等 go版的difflib会报错并且两个字符串相等并没有太大意义
	if lDist == 0 {
		//fmt.Println("[***][!]Two strings cannot be exactly the same")
		return false
	}
	// TrigramCompare 是 n-gram 的一种情况，它是来自给定样本的3个字符的连续序列，在另一个字符串中的连续情况
	tDiff := sd.TrigramCompare()
	//JaroDistance 两个单词之间的距离是将一个单词变为另一个单词所需的最小单字符转置数。结果越接近1表示越相近
	jDiff := sd.JaroDistance()


	if jDiff < 1 && jDiff > JDiffDegree {
		quota += 1
	}

	if tDiff < 1 && tDiff > TDiffDegree {
		quota += 1
	}
	if float64(lDist)/float64(len(sample)) < ChangeDistance {
		quota += 1
	}
	if quota == fineness {
		return true
	}
	return false
}

func PrefixAnalysis(sample, sample2 string) bool {
	sd := beda.NewStringDiff(sample, sample2)
	// JaroWinklerDistance 使用前缀比例，它为从开头匹配设置前缀长度的字符串提供更有利的评级
	jwDiff := sd.JaroWinklerDistance(0.1)
	if jwDiff < 1 && jwDiff > 0.9 {
		return true
	}
	return false
}
