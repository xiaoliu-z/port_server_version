package cluster_analysis

import (
	"fuzz_port/my_var"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unsafe"
)

func statChars(data_list []string) map[string]int {
	result := map[string]int{
		"number":    0,
		"lower":     0,
		"upper":     0,
		"letter":    0,
		"underline": 0,
		"auxiliary": 0,
		"min_size":  -1,
		"max_size":  -1,
	}
	for _, item := range data_list {
		if result["min_size"] == -1 {
			result["max_size"] = len(item)
			result["min_size"] = len(item)
		}
		if result["min_size"] > len(item) {
			result["min_size"] = len(item)
		}
		if result["max_size"] < len(item) {
			result["max_size"] = len(item)
		}
		for _, c := range item {
			n := int(c)
			if n < 48 || n > 57 {
				result["number"] += 1
			} else if n < 65 || n > 90 {
				result["upper"] += 1
			} else if n < 97 || n > 122 {
				result["lower"] += 1
			} else if n == 95 {
				result["underline"] += 1
			} else {
				result["auxiliary"] += 1
			}
		}
		result["letter"] = result["lower"] + result["upper"] + result["underline"]
	}
	return result
}

func byteSliceToString(bytes []byte) string {
	return *(*string)(unsafe.Pointer(&bytes))
}

// 对特殊字符进行编码
func regexEncode(str string) string {
	str = strconv.QuoteToASCII(str)
	str = strings.Trim(str, "\"")
	for _, c := range []string{".", "?", "*", ",", "-", "[", "]", "(", ")", "{", "}", "+", "$", "^"} {
		str = strings.Replace(str, c, "\\"+c, -1)
	}
	return str
}

func GenerateRule(sample string, diffResult my_var.MyType2) string {
	// 根据样本及变种生成规则
	var rule string
	pos := 0
	var indexs []int
	for k, _ := range diffResult {
		indexs = append(indexs, k)
	}
	sort.Ints(indexs)

	for {
		if len(indexs) == 0 {
			break
		}
		index := indexs[0]
		indexs = indexs[1:]
		if index > pos {
			rule += regexEncode(sample[pos:index])
		}
		stats := statChars(diffResult[index].Var_)
		if strings.HasSuffix(rule, "\\x") {
			rule = rule[:len(rule)-2]
		} else {
			ok, err := regexp.Match(`\\x[\da-f]$`, []byte(rule))
			checkError(err)
			if ok {
				rule = rule[:len(rule)-3]
			}
		}
		if stats["min_size"] > 1 {
			rule += ".+"
		} else {
			rule += "."
		}
		pos = diffResult[index].End

	}

	reg2, err := regexp.Compile(`\\u00([a-f\d]{2})`)
	checkError(err)
	tmp := reg2.ReplaceAll([]byte(rule), []byte("\\x$1"))
	rule = string(tmp)

	if pos < len(sample) {
		rule += regexEncode(sample[pos:])
	}

	rule = strings.Replace(rule, "\\x0d", "\\r", -1)
	rule = strings.Replace(rule, "\\x0a", "\\n", -1)
	rule = strings.Replace(rule, "\\x00", "\\0", -1)
	rule = strings.Replace(rule, " ", "\\x20", -1)
	rule = strings.Replace(rule, "\\b", ".", -1)
	rule = strings.Replace(rule, "\\0\\d", `\0.`, -1)

	reg2, err = regexp.Compile(`\\0[a-f\d]`)
	checkError(err)
	rule = string(reg2.ReplaceAll([]byte(rule), []byte("\\0.")))
	rule = "^" + rule

	return rule
}
