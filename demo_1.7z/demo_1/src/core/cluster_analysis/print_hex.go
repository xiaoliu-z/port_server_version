package cluster_analysis

import (
	"bytes"
	"fmt"
	"strconv"
	"strings"
)

func PrintHex(buf []byte, reqLen int) string{
	buffer := new(bytes.Buffer)
	num := 0
	start := 0
	buffer.WriteString(fmt.Sprintf("%06d   ", start))
	for _, b := range buf[:reqLen] {
		s := strconv.FormatInt(int64(b&0xff), 16)
		if len(s) < 2 {
			s = "0" + s
		}
		buffer.WriteString(s)
		buffer.WriteString(" ")
		num++
		if num%16 == 0 {
			start += 16
			for i := start - 16; i < start; i++ {
				tmpData := string(buf[i])
				tmpData=strings.Replace(tmpData, "\x00", `.`,-1)
				tmpData=strings.Replace(tmpData, "\x0a", `.`,-1)
				tmpData=strings.Replace(tmpData, "\x0b", `.`,-1)
				tmpData=strings.Replace(tmpData, "\x0c", `.`,-1)
				tmpData=strings.Replace(tmpData, "\n", `.`,-1)
				tmpData=strings.Replace(tmpData, "\t", `.`,-1)
				tmpData=strings.Replace(tmpData, "\r", `.`,-1)
				buffer.WriteString(tmpData)
			}
			buffer.WriteString("\n")
			buffer.WriteString(fmt.Sprintf("%06d   ", start))
		}
	}
	for {
		num++
		buffer.WriteString("   ")
		if num%16 == 0 {
			break
		}
	}
	for i := start; i < reqLen; i++ {
		tmpData := string(buf[i])
		tmpData=strings.Replace(tmpData, "\x00", `.`,-1)
		tmpData=strings.Replace(tmpData, "\x0a", `.`,-1)
		tmpData=strings.Replace(tmpData, "\x0b", `.`,-1)
		tmpData=strings.Replace(tmpData, "\x0c", `.`,-1)
		tmpData=strings.Replace(tmpData, "\t", `.`,-1)
		tmpData=strings.Replace(tmpData, "\n", `.`,-1)
		tmpData=strings.Replace(tmpData, "\r", `.`,-1)
		buffer.WriteString(tmpData)
	}
	// 转化为字符串
	return buffer.String()
}
