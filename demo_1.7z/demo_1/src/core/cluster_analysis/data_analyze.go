package cluster_analysis

import (
	"fmt"
	"fuzz_port/my_var"
	"strconv"
	"strings"

	"github.com/pmezard/go-difflib/difflib"
)

func checkError(err error) {
	if err != nil {
		fmt.Println(err)
	}
}

// MyDifflib 类似python的difflib 获取两个字符串的差异部分
func MyDifflib(str1 string, str2 string) (result []string) {
	//这里Context参数必须为3
	diff := difflib.ContextDiff{
		A:        difflib.SplitLines(str1),
		B:        difflib.SplitLines(str2),
		FromFile: "Original",
		ToFile:   "Current",
		Context:  3,
		Eol:      "\n",
	}
	tmp, _ := difflib.GetContextDiffString(diff)
	tmpSplit := strings.Split(tmp, "\n")
	if len(tmpSplit) > 3 {
		for _, i := range tmpSplit[3:] {
			if len(strings.TrimSpace(i)) > 0 {
				if strings.Contains(i, "*****") {
					continue
				}
				if strings.Contains(i, "***") || strings.Contains(i, "---") {
					result = append(result, i)
					continue
				}
				for j := 0; j < len(i)/3; j++ {
					result = append(result, i[j*3:j*3+3])
				}
			}
		}
	} else {
		fmt.Println("======="+
			"==========tmpSplit", tmpSplit)
	}
	return
}

func dataFix(diffItem my_var.MyType) my_var.MyType {
	// 去掉起始位置相同的字符
	// 起始坐标与字符不断后移
	for {
		if len(diffItem["l"].S) == 0 || len(diffItem["r"].S) == 0 {
			break
		}
		if diffItem["l"].S[0] == diffItem["r"].S[0] {
			diffItem["l"].P[0] += 1
			diffItem["r"].P[0] += 1
			diffItem["l"].S = diffItem["l"].S[1:]
			diffItem["r"].S = diffItem["r"].S[1:]
		} else {
			break
		}
	}
	// 去掉结尾相同的字符
	for {
		if len(diffItem["l"].S) == 0 || len(diffItem["r"].S) == 0 {
			break
		}
		if diffItem["l"].S[len(diffItem["l"].S)-1] == diffItem["r"].S[len(diffItem["r"].S)-1] {
			diffItem["l"].P[1] -= 1
			diffItem["r"].P[1] -= 1
			diffItem["l"].S = diffItem["l"].S[:len(diffItem["l"].S)-1]
			diffItem["r"].S = diffItem["r"].S[:len(diffItem["r"].S)-1]
		} else {
			break
		}
	}
	return diffItem
}

// DataDiff 两个字符串差异部分的整理
func DataDiff(str1 string, str2 string) []my_var.MyType {
	var result []my_var.MyType
	flag := false
	sameData := ""
	position := "o"
	var diffItem = my_var.MyType{}
	data := MyDifflib(str1, str2)
	for _, line := range data {
		if strings.HasPrefix(line, "*** ") {
			position = "l"
			if flag {
				if len(diffItem["r"].S) == 0 {
					diffItem["r"].S = sameData
				}
				tmp := dataFix(diffItem)
				result = append(result, tmp)
				diffItem = my_var.MyType{}
			}
			flag = true
			diffItem["l"] = &my_var.DiffItem{
				P: []int{0, 0},
				S: ""}
			diffItem["r"] = &my_var.DiffItem{
				P: []int{0, 0},
				S: ""}

			sameData = ""
			tmp := strings.Split(line, " ")[1]
			pos := strings.Split(tmp, ",")
			pos0, err := strconv.Atoi(pos[0])
			checkError(err)
			pos1, err := strconv.Atoi(pos[1])
			checkError(err)
			diffItem[position].P = []int{pos0 - 1, pos1}
		} else if strings.HasPrefix(line, "--- ") {
			position = "r"
			tmp := strings.Split(line, " ")[1]
			pos := strings.Split(tmp, ",")
			pos0, err := strconv.Atoi(pos[0])
			checkError(err)
			pos1, err := strconv.Atoi(pos[1])
			checkError(err)
			diffItem[position].P = []int{pos0 - 1, pos1}
		} else if len(line) == 3 && (line[0] == ' ' || line[0] == '!' || line[0] == '+' || line[0] == '-') {
			if line[0] == ' ' {
				sameData += line[2:3]
			}
			diffItem[position].S += line[2:3]
		}
	}

	if flag && (diffItem["l"].P[1] > 0 || diffItem["r"].P[1] > 0) {
		if len(diffItem["r"].S) == 0 {
			diffItem["r"].S = sameData
		}
		result = append(result, dataFix(diffItem))
	}

	return result
}

// DataAnalyze sample是目标端口响应,dataList是Fuzz数据库中与目标相似的数据
func DataAnalyze(sample string, dataList []string) my_var.MyType2 {
	var diffResult = make(my_var.MyType2)
	for _, sample2 := range dataList {
		diffItem := DataDiff(sample, sample2)
		for _, i := range diffItem {
			// postKey是初始位置 P[不同字符起始位置,终止位置]
			// S:不同的字符串
			posKey := i["l"].P[0]
			// 如果没有就创建
			if _, ok := diffResult[posKey]; !ok {
				diffResult[posKey] = &my_var.DiffResult{
					End:  i["l"].P[1],
					Var_: []string{i["l"].S, i["r"].S},
				}
				continue
			}
			// 结尾更长对不相同字符串的扩展
			if diffResult[posKey].End <= i["l"].P[1] {
				for j := range diffResult[posKey].Var_ {
					diffResult[posKey].Var_[j] += sample[diffResult[posKey].End:i["l"].P[1]]
				}
				diffResult[posKey].Var_ = append(diffResult[posKey].Var_, i["r"].S)
				diffResult[posKey].End = i["l"].P[1]
			} else {
				diffResult[posKey].Var_ = append(diffResult[posKey].Var_, i["r"].S+sample[i["l"].P[1]:diffResult[posKey].End])
			}
		}
	}

	return diffResult
}
