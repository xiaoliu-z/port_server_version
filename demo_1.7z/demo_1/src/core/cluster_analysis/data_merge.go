package cluster_analysis

import (
	"fmt"
	"fuzz_port/my_var"
	"sort"
)

func removeDuplicate(arr []string) []string {
	resArr := make([]string, 0)
	tmpMap := make(map[string]interface{})
	for _, val := range arr {
		//判断主键为val的map是否存在
		if _, ok := tmpMap[val]; !ok {
			resArr = append(resArr, val)
			tmpMap[val] = nil
		}
	}

	return resArr
}

func judgeRange(key int, tmpSlice []int) bool {
	if len(tmpSlice) == 0 {
		return false
	}
	if key < tmpSlice[0] || key > tmpSlice[len(tmpSlice)-1] {
		return false
	}
	for _, i := range tmpSlice {
		if i == key {
			return true
		}
	}
	return false
}

func DataMerge(sample string, diffResult my_var.MyType2) my_var.MyType2 {
	var dataPositions []int
	var delPositions []int
	for k := range diffResult {
		dataPositions = append(dataPositions, k)
	}
	sort.Ints(dataPositions)
	for _, position := range dataPositions {
		if judgeRange(position, delPositions) {
			continue
		}
		for _, j := range dataPositions {
			if j <= position {
				continue
			}

			if j <= diffResult[position].End {
				if diffResult[j].End > diffResult[position].End {
					diffResult[position].Var_[0] += sample[diffResult[position].End:diffResult[j].End]
					diffResult[position].End = diffResult[j].End
					diffResult[position].Var_ = append(diffResult[position].Var_, diffResult[j].Var_...)
				} else {
					prefix := sample[position:j]
					suffix := sample[diffResult[j].End:diffResult[position].End]
					for _, s := range diffResult[j].Var_ {
						diffResult[position].Var_ = append(diffResult[position].Var_, fmt.Sprintf("%s%s%s", prefix, s, suffix))
					}
				}
				delPositions = append(delPositions, j)
			} else {
				break
			}
		}
	}

	//删除交叉的不同区块

	for i := 0; i <= len(delPositions)-1; i++ {
		delete(diffResult, delPositions[i])
	}

	for i := range diffResult {
		diffResult[i].Var_ = removeDuplicate(diffResult[i].Var_)
		tmpVar := diffResult[i].Var_
		var nullKey []int
		for i, k := range tmpVar {
			if k == "" {
				nullKey = append(nullKey, i)
			}
		}
		for _, key := range nullKey {
			tmpVar = append(tmpVar[:key], tmpVar[key+1:]...)
		}
		diffResult[i].Var_ = tmpVar
	}
	return diffResult
}
