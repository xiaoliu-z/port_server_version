package api

import (
	"encoding/base64"
	"fmt"
	"fuzz_port/core/cluster_analysis"
	"fuzz_port/core/probe_scan"
	"fuzz_port/my_var"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/panjf2000/ants/v2"
	"github.com/sirupsen/logrus"
)

var (
	// 每个目标第一次端口响应探测
	pool *ants.Pool
	// 指纹补全
	pool2 *ants.Pool
	// 响应补全(第一次探测没获得结果)
	pool3 *ants.Pool
	// 充当用户提交api 与 信息探测的消息队列
	channel chan my_var.Target
	// 充当信息探测成功 与 聚类分析生成指纹的消息队列
	channel2 chan my_var.Target2
	// 获取用于聚类分析的响应数据
	log = logrus.New()
	m   sync.Mutex
	m2  sync.Mutex
)

func init() {
	channel = make(chan my_var.Target, my_var.CONFIG.Config.Consumer)
	channel2 = make(chan my_var.Target2, my_var.CONFIG.Config.Consumer2)

	pool, _ = ants.NewPool(my_var.CONFIG.Config.GoNumCollection)
	pool2, _ = ants.NewPool(my_var.CONFIG.Config.GoNumAnalysis)
	pool3, _ = ants.NewPool(100)

	for i := 0; i < my_var.CONFIG.Config.GoNumCollection; i++ {
		err := pool.Submit(DataCollection)
		if err != nil {
			fmt.Println(err)
		}
	}

	for i := 0; i < my_var.CONFIG.Config.GoNumAnalysis; i++ {
		err := pool2.Submit(DataAnalysis)
		if err != nil {
			fmt.Println(err)
		}
	}

	Dispatch()
}

// DataAnalysis error_type  0:无错误、1:获取端口响应失败、2:获取符合相似性字符串数量不够、3:正则验证失败
func DataAnalysis() {
	var samples []int64
	var dataList []string
	var target2 my_var.Target2

	select {
	case target2 = <-channel2:

		prefix := 1
		tmp, _ := base64.StdEncoding.DecodeString(target2.Sample)
		sample := string(tmp)
		// 响应匹配指纹

		// 如果响应为HTTP不进行聚类
		if strings.HasPrefix(sample, "HTTP") {
			goto End
		}

		// 字符串相似度判断
		if cluster_analysis.SimilarityAnalysis(sample, "", int32(my_var.CONFIG.Config.Similarity)) {
			dataList = append(dataList, "")
			if len(dataList) >= my_var.CONFIG.Config.SimilarQuantity {
				break
			}
		}

	Analysis:
		if prefix == 0 {
		}
		var diffResult my_var.MyType2
		var resultRule string
		// 相似数量不足会将响应存放到Fuzz表中
		if len(dataList) < my_var.CONFIG.Config.SimilarQuantity {
			if prefix == 0 {
				goto End
			} else {
				goto Prefix
			}
		}

		// 聚类分析生成指纹
		diffResult = cluster_analysis.DataAnalyze(sample, dataList)
		diffResult = cluster_analysis.DataMerge(sample, diffResult)
		resultRule = cluster_analysis.GenerateRule(sample, diffResult)

		fmt.Println(resultRule)
		// 增加指纹对应服务
		if prefix == 0 {
		} else {
		}

	Prefix:
		if prefix == 0 {
			goto End
		} else {
			// 字符串相似度判断
			dataList = dataList[:0]
			samples = samples[:0]

			if cluster_analysis.PrefixAnalysis(sample, "") {
				dataList = append(dataList, "")
				if len(dataList) >= my_var.CONFIG.Config.SimilarQuantity {

				}

			}
			prefix = 0
			goto Analysis
		}

	case <-time.After(15 * time.Second):
	}
End:
}

// DataCollection DataC 对用户传入的ip、port进行端口探测
func DataCollection() {
	var target my_var.Target // 用户输入的目标信息
	var plainText string

	// 获取用户通过api传入的目标
	select {
	case target = <-channel:
		// 将目标进行端口响应收集 返回探针ip和byte形式的响应
		probeId, byteSample := probe_scan.Scan(target.Protocol, target.Ip, target.Port)
		sample := base64.StdEncoding.EncodeToString(byteSample)

		// 跟据端口响应情况进行不同的存储
		if string(byteSample) == "can't get banner" {
			log.Infof("目标id %s can't get banner", target)
		} else if string(byteSample) == "empty response" {
			log.Infof("目标id %s empty banner", target)
		} else {
			if len(byteSample) > 2048 {
				sample = base64.StdEncoding.EncodeToString(byteSample[:2048])
				plainText = strings.Trim(strconv.QuoteToASCII(string(byteSample[:2048])), "\"")
			} else {
				sample = base64.StdEncoding.EncodeToString(byteSample)
				plainText = strings.Trim(strconv.QuoteToASCII(string(byteSample)), "\"")
			}
			channel2 <- my_var.Target2{PlainText: plainText, Sample: sample, ProbeId: probeId}
		}
	case <-time.After(20 * time.Second):
	}
}

// Dispatch 每隔一段时间就补全数据库中残缺的内容+调度正在运行的goroutine数量
func Dispatch() {
	// 补全指纹 (fuzz相似数据不足、正则验证失败)
	go func() {

	}()

	// 根据任务量调控目标端口信息收集并发数
	go func() {
		// 1:最低要有两个goroutine在运行 2:运行的goroutine数量是消息池内任务的2/3 3: goroutine数量最高不超过500 4:变化速度要快
		for {
			time.Sleep(time.Second * 20)
			task := (len(channel) / 3) * 2
			if pool.Running() == 0 {
				for i := 0; i < my_var.CONFIG.Config.GoNumCollection; i++ {
					pool.Submit(DataCollection)
				}
			}
			if pool.Running() < task {
				if task > 500 {
					task = 500
					pool.Tune(500)
				} else {
					if pool.Cap() < task {
						pool.Tune(task)
					}
				}
				for i := pool.Running(); i <= task; i++ {
					pool.Submit(DataCollection)
				}
			}

			if len(channel) < 40 && pool.Running() < 40 {
				pool.Tune(40)
			}
		}
	}()

	// 根据任务量调控生成指纹并发数
	go func() {
		// 1:最低要有两个goroutine在运行 2:运行的goroutine数量是消息池内任务的2/3 3: goroutine数量最高不超过300 4:变化速度要快
		for {
			time.Sleep(time.Second * 20)
			task := (len(channel2) / 3) * 2
			if pool2.Running() == 0 {
				for i := 0; i < my_var.CONFIG.Config.GoNumAnalysis; i++ {
					pool2.Submit(DataAnalysis)
				}
			}
			if pool2.Running() < task {
				if task > 200 {
					task = 200
					pool2.Tune(200)
				} else {
					if pool2.Cap() < task {
						pool2.Tune(task)
					}
				}
				for i := pool2.Running(); i <= task; i++ {
					pool2.Submit(DataAnalysis)
				}
			}

			if len(channel2) < 30 && pool2.Running() < 30 {
				pool2.Tune(30)
			}
		}
	}()

	// 定期检测端口响应在时间维度生成指纹
	go func() {
	}()

	// 补全banner (获取端口响应失败)
	go func() {
	}()
}

func Run() http.Handler {
	log.Formatter = &logrus.JSONFormatter{}
	f, _ := os.Create(my_var.CONFIG.Config.Route.LogSource + "api.log")
	log.Out = f
	log.Level = logrus.InfoLevel

	// 默认模式启动 使用了Logger(), Recovery()这两个中间件
	r := gin.Default()
	// 验证令牌
	r.Use(CheckToken())
	// 检查传入内容
	r.Use(PostCheck())
	// 验证指纹
	r.Use(CheckRule())
	// 获取数据库连接

	// 第三方脚本POST请求通过此API提交未知协议端口及对应地址
	r.POST("/push_target", func(c *gin.Context) {
		ip := c.PostForm("ip")
		port := c.GetInt64("port")
		protocol := c.PostForm("protocol")
		fmt.Println(ip, port, protocol)
		channel <- my_var.Target{
			Port:     port,
			Protocol: protocol,
			Ip:       ip,
		}
		c.JSON(http.StatusOK, gin.H{
			"code": "200",
			"msg":  "submit target success",
			"data": "",
		})
	})

	// 拉取审核通过的指纹。
	r.GET("/pull_rule", func(c *gin.Context) {

	})

	return r
}
