package api

import (
	"fuzz_port/my_var"
	"github.com/gin-gonic/gin"
	"net"
	"net/http"
	"strconv"
	"strings"
)

const (
	SuccessCode = 1
	ErrCode     = 0
)

func ParseToken(authHeader string) bool {
	if authHeader == my_var.CONFIG.Config.Auth.ApiToken[0] || authHeader == my_var.CONFIG.Config.Auth.ApiToken[1] {
		return true
	}
	return false
}

func PostCheck() gin.HandlerFunc {
	return func(c *gin.Context) {
		var code int
		var errStr string

		// 对传入的 ip、port、protocol进行格式检查
		if c.Request.RequestURI == "/push_target" {
			code = SuccessCode
			ip := c.DefaultPostForm("ip", "")
			tmpPort := c.DefaultPostForm("port", "")
			protocol := c.DefaultPostForm("protocol", "")

			if len(ip) == 0 || len(tmpPort) == 0 || len(protocol) == 0 {
				code = ErrCode
				errStr = "请输入将参数输入完整"
			} else {
				if protocol != "tcp" && protocol != "udp" {
					code = ErrCode
					errStr = "请输入正确的协议"
					goto CHECK
				}

				ok := net.ParseIP(ip)
				if ok == nil {
					code = ErrCode
					errStr = "ip格式不符合"
					goto CHECK
				}

				port, err := strconv.Atoi(c.PostForm("port"))
				if err != nil {
					code = ErrCode
					errStr = "port应该是数字整数"
					goto CHECK
				}

				if port < 1 || port > 65535 {
					code = ErrCode
					errStr = "port超出范围"
					goto CHECK
				}
				c.Set("port", int64(port))
			}

		CHECK:
			if code != SuccessCode {
				c.JSON(http.StatusBadRequest, gin.H{
					"code": code,
					"msg":  errStr,
					"data": "",
				})
				c.Abort()
				return
			}
		}

		c.Next()
	}
}

func CheckToken() gin.HandlerFunc {
	return func(c *gin.Context) {
		var code int
		var data interface{}
		var errStr string

		code = SuccessCode
		token := c.Request.Header.Get("Fuzz-Api-Token")

		if token == "" {
			// 非登录状态
			code = ErrCode
			errStr = "请登录后操作"
		} else {
			ok := ParseToken(token)
			if !ok {
				code = ErrCode
				errStr = "身份验证失败，请检查输入格式及令牌是否正确"
			}
		}

		if code != SuccessCode {
			c.JSON(http.StatusUnauthorized, gin.H{
				"code": code,
				"msg":  errStr,
				"data": data,
			})
			c.Abort()
			return
		}
		c.Next()
	}
}

func CheckRule() gin.HandlerFunc {
	return func(c *gin.Context) {
		if c.Request.RequestURI == "/pull_target" && strings.HasPrefix(c.DefaultQuery("rule", ""), "^"){
			c.JSON(http.StatusBadRequest, gin.H{
				"code": ErrCode,
				"msg":  "请输入正确的正则表达式",
				"data": "",
			})
			c.Abort()
			return
		}
		c.Next()
	}
}
