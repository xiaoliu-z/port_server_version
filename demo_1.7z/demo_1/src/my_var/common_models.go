package my_var

import "time"

// ================================= 手工生成Set部分 =================================
type Set map[string]struct{}

func (s Set) Has(key string) bool {
	_, ok := s[key]
	return ok
}

func (s Set) Add(key string) {
	s[key] = struct{}{}
}

func (s Set) Delete(key string) {
	delete(s, key)
}

// ================================= 解析配置文件部分 =================================

type Route struct {
	DbUser     string `yaml:"DbUser"`
	DbPassword string `yaml:"DbPassword"`
	DbIp       string `yaml:"DbIp"`
	DbPort     int    `yaml:"DbPort"`
	DbName     string `yaml:"DbName"`
	LogSource  string `yaml:"LogSource"`
}

type Auth struct {
	User     string   `yaml:"User"`
	Password string   `yaml:"Password"`
	ApiToken []string `yaml:"ApiToken"`
}

type Config struct {
	Auth               Auth   `yaml:"auth"`
	Route              Route  `yaml:"route"`
	ApiPort            string `yaml:"ApiPort"`
	Consumer           int    `yaml:"Consumer"`
	Consumer2          int    `yaml:"Consumer2"`
	ReadTimeout        int    `yaml:"ReadTimeout"`
	WriteTimeout       int    `yaml:"WriteTimeout"`
	SocketReadTimeout  int    `yaml:"SocketReadTimeout"`
	SocketWriteTimeout int    `yaml:"SocketWriteTimeout"`
	GoNumAnalysis      int    `yaml:"GoNumAnalysis"`
	GoNumCollection    int    `yaml:"GoNumCollection"`
	Similarity         int    `yaml:"Similarity"`
	SimilarQuantity    int    `yaml:"SimilarQuantity"`
}

type MyYaml struct {
	Config Config `yaml:"config"`
}

// ================================= 异步模式channel中的类型 =================================

type Parameter struct {
	Mode, Protocol, Ip, Targets, Target_file, Output string
	Port                                             int64
	Delay                                            time.Duration
}

type Target struct {
	Port     int64
	Protocol string
	Ip       string
}

type FuzzResult struct {
	Protocol string
	Ip       string
	Port     int64
	Rules    []string
}

type Target2 struct {
	PlainText string
	Sample    string
	ProbeId   int64
}
