package my_var


// ================================= 聚类分析部分 =================================

// DiffResult End 不同内容结束部分  Var_ 存放在各字符串在此处不同的内容
type DiffResult struct {
	End  int
	Var_ []string
}

// DiffItem P[起点下标:终点下标] S"不同的字符串"
type DiffItem struct {
	P []int
	S string
}

type MyType map[string]*DiffItem

type MyType2 map[int]*DiffResult


