package my_var

import (
	"bytes"
	"crypto/rand"
	"crypto/rsa"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"fmt"
	"math/big"
	"net"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
)

func CheckError(err error) {
	if err != nil {
		fmt.Println(err)
	}
}

// Convert go默认使用utf-8，遇到非utf-8的字节就无法匹配字符编码,所以go中的regexp有些问题,这里进行处理
func Convert(src string) string {
	var dst = ""
	for i, r := range src {
		var v = ""
		if r == utf8.RuneError {
			v = string(src[i])
		} else {
			v = string(r)
		}
		dst += v
	}
	return dst
}

//================================= 探针部分 =================================

// Probe 数据库中取出探针对应的结构体
type Probe struct {
	probeId     int64
	totalwaitms int64
	priority    int64
	ports       string
	sslports    string
	probestring []byte
}

// ProbeResult 探针Result 端口响应返回
type ProbeResult struct {
	ProbeId  int64
	Priority int64
	Banner   []byte
}

type ProbeScan struct {
	Protocol string
	Ip       string
	Port     int64
	Probes   []Probe
	Result   ProbeResult
	TlsConf  *tls.Config
}

func GenerateSelfSignedCertKey(keySize int, host string, alternateIPs []net.IP, alternateDNS []string) ([]byte, []byte) {
	//1.生成密钥对
	priv, err := rsa.GenerateKey(rand.Reader, keySize)
	if err != nil {
		panic(err)
	}
	//2.创建证书模板
	template := x509.Certificate{
		SerialNumber: big.NewInt(1), //该号码表示CA颁发的唯一序列号，在此使用一个数来代表
		Issuer:       pkix.Name{},
		Subject:      pkix.Name{CommonName: fmt.Sprintf("%s@%d", host, time.Now().Unix())},
		NotBefore:    time.Now(),
		NotAfter:     time.Now().Add(time.Hour * 24 * 365),
		KeyUsage:     x509.KeyUsageKeyEncipherment | x509.KeyUsageDigitalSignature | x509.KeyUsageCertSign, //表示该证书是用来做服务端认证的
		ExtKeyUsage:  []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
	}

	if ip := net.ParseIP(host); ip != nil {
		template.IPAddresses = append(template.IPAddresses, ip)
	} else {
		template.DNSNames = append(template.DNSNames, host)
	}

	template.IPAddresses = append(template.IPAddresses, alternateIPs...)
	template.DNSNames = append(template.DNSNames, alternateDNS...)

	//3.创建证书,这里第二个参数和第三个参数相同则表示该证书为自签证书，返回值为DER编码的证书
	certificate, err := x509.CreateCertificate(rand.Reader, &template, &template, &priv.PublicKey, priv)
	if err != nil {
		panic(err)
	}
	//4.将得到的证书放入pem.Block结构体中
	block := pem.Block{
		Type:    "CERTIFICATE",
		Headers: nil,
		Bytes:   certificate,
	}
	//5.通过pem编码并写入磁盘文件
	buf1 := bytes.NewBufferString("")
	pem.Encode(buf1, &block)

	//6.将私钥中的密钥对放入pem.Block结构体中
	block = pem.Block{
		Type:    "RSA PRIVATE KEY",
		Headers: nil,
		Bytes:   x509.MarshalPKCS1PrivateKey(priv),
	}
	buf2 := bytes.NewBufferString("")
	pem.Encode(buf2, &block)

	return buf1.Bytes(), buf2.Bytes()
}

func GetData(protocol string) []Probe {
	var resultProbe []Probe

	return resultProbe
}

var TcpProbe = GetData("tcp")
var UDPProbe = GetData("tcp")

// IsInRange 对端口范围进行判断
func (p *ProbeScan) IsInRange(ports string) bool {
	if len(ports) == 0 {
		return true
	} else {
		for _, tmpPort := range strings.Split(ports, "_") {
			if strings.Contains(tmpPort, "-") {
				t := strings.Split(tmpPort, "-")
				l, err := strconv.Atoi(t[0])
				CheckError(err)
				r, err := strconv.Atoi(t[1])
				CheckError(err)
				if p.Port >= int64(l) && p.Port <= int64(r) {
					return true
				}
			} else {
				if strconv.Itoa(int(p.Port)) == tmpPort {
					return true
				}
			}
		}
	}
	return false
}

// UseProbe  对符合条件的目标并发探测
func (p *ProbeScan) UseProbe() {
	// 给ssl留下位子
	for i := 0; i < len(p.Probes); i++ {
		if p.IsInRange(p.Probes[i].ports) {
			time.Sleep(5 * time.Millisecond)
			p.GetResponse(p.Probes[i])
			if string(p.Result.Banner) == "empty response" || len(p.Result.Banner) == 0 {
				continue
			}
			break
		}
	}
}

func (p *ProbeScan) AllProbe() {
	for i := 0; i < len(p.Probes); i++ {
		if !p.IsInRange(p.Probes[i].ports) {
			time.Sleep(5 * time.Millisecond)
			p.GetResponse(p.Probes[i])
			if string(p.Result.Banner) == "empty response" || len(p.Result.Banner) == 0 {
				continue
			}
			break
		}
	}
}

func (p *ProbeScan) SslScan() {
	for i := 0; i < len(p.Probes); i++ {
		time.Sleep(5 * time.Millisecond)
		p.GetSslResponse(p.Probes[i])
		if string(p.Result.Banner) == "empty response" || len(p.Result.Banner) == 0 {
			continue
		}
		break
	}
}

func (p *ProbeScan) GetSslResponse(tmpProbe Probe) {
	var address string

	if strings.Contains(p.Ip, ":") {
		address = "[" + p.Ip + "]"
	} else {
		address = p.Ip
	}
	address = address + ":" + strconv.Itoa(int(p.Port))
	conn, err := tls.Dial(p.Protocol, address, p.TlsConf)
	if err != nil {
		fmt.Println(err)
		return
	} else {
		conn.Write(tmpProbe.probestring)
		buf := [2048]byte{}
		n, err := conn.Read(buf[:])
		if err != nil {
			if err.Error() == "EOF" {
				p.Result.ProbeId = tmpProbe.probeId
				p.Result.Priority = tmpProbe.priority
				p.Result.Banner = []byte("empty response")
				conn.Close()
				return
			}
			fmt.Println("2", err)
		}
		fmt.Println(string(buf[:n]))
		p.Result.ProbeId = tmpProbe.probeId
		p.Result.Priority = tmpProbe.priority
		p.Result.Banner = buf[:n]
		conn.Close()
	}
}

// GetResponse 获取某个探针下的端口响应
func (p *ProbeScan) GetResponse(tmpProbe Probe) {
	var address string
	var n int
	var buf [3072]byte

	if strings.Contains(p.Ip, ":") {
		address = "[" + p.Ip + "]"
	} else {
		address = p.Ip
	}
	address = address + ":" + strconv.Itoa(int(p.Port))
	conn, err := net.DialTimeout(p.Protocol, address, 10*time.Second)
	if err != nil {
		goto End
	}
	defer conn.Close()
	err = conn.SetReadDeadline(time.Now().Add(10 * time.Second))
	err = conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
	if err != nil {
		goto End
	}

	if len(tmpProbe.probestring) > 0 {
		_, err = conn.Write(tmpProbe.probestring)
		if err != nil {
			goto End
		}
	}

	buf = [3072]byte{}
	n, err = conn.Read(buf[:])
	if err != nil {
		if err.Error() == "EOF" {
			p.Result.ProbeId = tmpProbe.probeId
			p.Result.Priority = tmpProbe.priority
			p.Result.Banner = []byte("empty response")
			goto End
		}
	}
	// 没报错且长度为空
	p.Result.ProbeId = tmpProbe.probeId
	p.Result.Priority = tmpProbe.priority
	p.Result.Banner = buf[:n]

End:
}
