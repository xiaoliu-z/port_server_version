package cmd

import (
	"fuzz_port/api"
	"fuzz_port/my_var"
	"golang.org/x/sync/errgroup"
	"log"
	"net/http"
	"time"
)

var g errgroup.Group

func Run() {
	//Restful API 配置
	apiServer := &http.Server{
		Addr:         my_var.CONFIG.Config.ApiPort,
		Handler:      api.Run(),
		ReadTimeout:  time.Duration(my_var.CONFIG.Config.ReadTimeout),
		WriteTimeout: time.Duration(my_var.CONFIG.Config.WriteTimeout),
	}

	// 开启Restful API
	g.Go(func() error {
		return apiServer.ListenAndServe()
	})

	if err := g.Wait(); err != nil {
		log.Fatal(err)
	}
}
