package cmd

import (
	"fuzz_port/my_var"
	"os"

	"gopkg.in/yaml.v3"
)

func GetConfig(conf *my_var.MyYaml) {
	if f, err := os.Open("config.yaml"); err != nil {
		panic(err)
	} else {
		err := yaml.NewDecoder(f).Decode(conf)
		if err != nil {
			panic(err)
		}
	}
}

func INIT() {
	// init probe
	GetConfig(my_var.CONFIG)
}
