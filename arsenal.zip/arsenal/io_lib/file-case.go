package io_lib

import (
	"bufio"
	"os"
	"strings"
)

// LinesInFile 读取文件 返回每行的数组
func LinesInFile(fileName string) ([]string, error) {
	result := []string{}
	f, err := os.Open(fileName)
	if err != nil {
		return result, err
	}
	defer f.Close()
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := scanner.Text()
		line = strings.Trim(line,"\n")
		if line != "" {
			result = append(result, line)
		}
	}
	return result, nil
}