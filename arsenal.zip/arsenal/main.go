package main

import (
	"arsenal/log"
)

func main() {
	log.Init(true, false)
	log.Logger.Println("a")

}