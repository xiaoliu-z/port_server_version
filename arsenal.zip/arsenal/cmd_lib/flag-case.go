package cmd_lib

import (
	"flag"
	"fmt"
)


func FlagCase() {
	// 定义命令行参数
	ip := flag.String("ip", "", "要扫描的IP地址")
	port := flag.Int("port", 0, "要扫描的端口号")
	output := flag.String("output", "", "结果输出文件")

	// 解析命令行参数
	flag.Parse()

	// 使用解析后的参数
	fmt.Println("IP地址:", *ip)
	fmt.Println("端口号:", *port)
	fmt.Println("输出文件:", *output)
}