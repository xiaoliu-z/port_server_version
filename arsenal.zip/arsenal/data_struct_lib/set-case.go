package data_struct_lib

func Sets(array []string) []string {
	m := make(map[string]interface{})
	for _, item := range array {
		m[item] = nil
	}
	var ret []string
	for k, _ := range m {
		ret = append(ret, k)
	}
	return ret
}
