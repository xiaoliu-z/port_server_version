package third_tool_lib

import (
	"errors"
	"github.com/miekg/dns"
	"golang.org/x/net/publicsuffix"
)

// GetTopDomain 获取顶级域名 a.game.baidu.com ---> baidu.com
func GetTopDomain(domain string) (string, error) {
	return publicsuffix.EffectiveTLDPlusOne(domain)
}

// LookupNS 同构dns查询获取域名的NS记录
func LookupNS(domain, serverAddr string) ([]string, error) {
	servers := []string{}
	m := &dns.Msg{}
	m.SetQuestion(dns.Fqdn(domain), dns.TypeNS)
	in, err := dns.Exchange(m, serverAddr+":53")
	if err != nil {
		return servers, err
	}
	if len(in.Answer) < 1 {
		return servers, errors.New("no Answer")
	}
	for _, a := range in.Answer {
		if ns, ok := a.(*dns.NS); ok {
			servers = append(servers, ns.Ns)
		}
	}
	return servers, nil
}