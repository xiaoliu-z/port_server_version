package standard_lib

import (
	"fmt"
	"math"
)

func MathCase() {
	fmt.Println("2^10:=", math.Pow(2, 10))
	fmt.Println("返回以2为底，1024的对数", math.Log2(1024))
	fmt.Println("返回两个数中较大的值:", math.Max(2, 10))
	fmt.Println("向上取整",math.Ceil(2.49))
	fmt.Println("向下取整",math.Floor(2.89))
}
