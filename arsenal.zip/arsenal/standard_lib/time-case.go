package standard_lib

import (
	"fmt"
	"time"
)

func TimeCase() {
	//时间转字符串
	var t time.Time
	t = time.Now()
	timeStr := t.Format("2006-01-02 15:04:05Z07:00")
	fmt.Println(timeStr)
	t2, _ := time.Parse("2006-01-02 15:04:05Z07:00", timeStr)
	fmt.Println(t2)
}
