package standard_lib

import (
	"encoding/hex"
	"fmt"
	"os"
)

func FmtCase() {
	var baseStr = "Tom"
	fmt.Println(baseStr)
	fmt.Printf("你好%s", baseStr)
	// 输出到IO
	str := fmt.Sprintf("你好%s\n", baseStr)
	fmt.Fprint(os.Stdout, str)
	// 类似hex输出
	dump := hex.Dump([]byte(baseStr))
	fmt.Println(dump)
}

func FmtCase1() {
	type simple struct {
		value int
	}
	a := simple{value: 10}
	// 通用占位符
	fmt.Printf("默认格式的值:%v\n", a)
	fmt.Printf("包含字段名的值:%+v\n", a)
	fmt.Printf("go语法表示的值:%#v\n", a)
	fmt.Printf("go语法表示的类型:%T\n", a)
	fmt.Printf("输出字面上的百分号:%%10\n")
	// 整数占位符
	v1 := 10
	v2 := 20170 // "今"
	fmt.Printf("二进制:%b\n", v1)
	fmt.Printf("Unicode 码点转字符:%c\n", v2)
	fmt.Printf("十进制:%d\n", v1)
	fmt.Printf("八进制:%o\n", v1)
	fmt.Printf("有前缀的八进制:%O\n", v1)
	fmt.Printf("用单引号将字符值包起来:%q\n", v2)
	fmt.Printf("十六进制:%x\n", v1)
	fmt.Printf("大写十六进制:%X\n", v1)
	fmt.Printf("Unicode格式:%U\n", v1)

	//宽度设置
	fmt.Printf("%v的二进制:%b;go语法表示的二进制为:%#b；指定二进制宽度为8，不足8位补0:%08b \n", v1, v1, v1, v1)
	fmt.Printf("%v的十六进制:%x;go语法表示的十六进制为:%#x；指定十六进制宽度为8，不足8位补0:%08x \n", v1, v1, v1, v1)
	fmt.Printf("%v的十六进制:%x;go语法表示的十六进制为:%#x；指定十六进制宽度为8，不足8位补空格:%8x \n", v1, v1, v1, v1)

	// 浮点数占位符
	var f1 = 123.789
	var f2 = 1234567890.7899

	fmt.Printf("指数为二的幂的无小数科学计数法:%b \n", f1)
	fmt.Printf("科学计数法:%e \n", f1)
	fmt.Printf("科学计数法:%E \n", f1)
	fmt.Printf("常规浮点数:%f \n", f1)
	fmt.Printf("宽度为9精度默认:%9f \n", f1)
	fmt.Printf("宽度默认精度保留两位小鼠:%.2f \n", f1)
	fmt.Printf("宽度为9精度保留两位小数:%9.2f \n", f1)
	fmt.Printf("宽度为9精度保留0位小数:%9.f \n", f1)
	fmt.Printf("根据情况自动选择%%e还是%%f:%g ,%g\n", f1, f2)

	// 字符串占位符
	var str = "今天"
	fmt.Printf("%s \n", str)
	fmt.Printf("%q \n", str)
	fmt.Printf("%x \n", str)
	fmt.Printf("%X \n", str)
	// 以空格作为两数之间的分割符
	fmt.Printf("% X \n", str)

	// 指针占位符
	var str1 = "今天"
	bytes := []byte(str1)
	fmt.Printf("%p\n", bytes)
	mp := make(map[string]int, 0)
	fmt.Printf("%p \n", mp)
	var p *map[string]int = new(map[string]int)
	fmt.Printf("%p \n", p)

}
