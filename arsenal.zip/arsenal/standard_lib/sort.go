package standard_lib

import (
	"fmt"
	"sort"
)

type sortUser struct {
	ID   int64
	Name string
	Age  uint8
}
type ByID []sortUser

// 获取长度
func (b ByID) Len() int {
	return len(b)
}

// 交换位置
func (b ByID) Swap(i, j int) {
	b[i], b[j] = b[j], b[i]
}
func (b ByID) Less(i, j int) bool {
	return b[i].ID < b[j].ID
}

func SortCase() {
	list := []sortUser{
		{ID: 10, Name: "nick", Age: 18},
		{ID: 11, Name: "nick", Age: 16},
		{ID: 9, Name: "nick", Age: 19},
	}
	sort.Slice(list, func(i, j int) bool {
		return list[i].Age < list[j].Age
	})
	fmt.Println(list)

	// 实现sort.Interface接口
	sort.Sort(ByID(list))
	fmt.Println(list)
}
