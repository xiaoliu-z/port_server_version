package standard_lib

import (
	"errors"
	"fmt"
	"log"
	"time"
)

type cusError struct {
	Code string
	Msg  string
	Time time.Time
}

func (err cusError) Error() string {
	return fmt.Sprintf("Code:%s,Msg:%s,Time:%s", err.Code, err.Msg, err.Time.Format("2021-03-17 07:13:24"))
}

func getCusError(code, msg string) error {
	return cusError{
		Code: code,
		Msg:  msg,
		Time: time.Now(),
	}
}

func ErrorCase() {
	// 标准库
	err := errors.New("程序发生了错误")
	fmt.Println(err)
	// 自定义错误
	var a, b = -1, 2
	res, err := sum(a, b)
	fmt.Println(res)
	if err != nil {
		log.Println(err)
		cusErr, ok := err.(cusError)
		if ok {
			fmt.Println("打印自定义错误信息:", cusErr.Error())
		}
	}
}
func sum(a, b int) (int, error) {
	if a <= 0 || b <= 0 {
		return 0, getCusError("500", "不能为负数")
	}
	return a + b, nil
}
